// Get all slides

const slides = document.querySelectorAll('.slide');

let currentSlide = 0;

// Show the first slide

slides[currentSlide].classList.add('active');

// Function to go to the next slide

function nextSlide() {

  slides[currentSlide].classList.remove('active');

  currentSlide++;

  if (currentSlide >= slides.length) currentSlide = slides.length - 1; // stay at last slide

  slides[currentSlide].classList.add('active');

}

// Function for the Valentine date slide (optional)

function showValentineSlide() {

  slides[currentSlide].classList.remove('active');

  currentSlide = slides.length - 2; // assuming 2nd to last slide is Valentine date

  slides[currentSlide].classList.add('active');

}

// Function for the goofy face slide

function showGoofySlide() {

  slides[currentSlide].classList.remove('active');

  currentSlide = slides.length - 1; // last slide

  slides[currentSlide].classList.add('active');

}
